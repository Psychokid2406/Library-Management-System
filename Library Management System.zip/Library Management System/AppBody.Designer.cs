﻿
namespace Library_Management_System
{
    partial class AppBody
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sliding_timer = new System.Windows.Forms.Timer(this.components);
            this.contentPanel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.abouttab = new System.Windows.Forms.Button();
            this.bookstab = new System.Windows.Forms.Button();
            this.borrowertab = new System.Windows.Forms.Button();
            this.settingstab = new System.Windows.Forms.Button();
            this.transactiontab = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1006, 36);
            this.panel1.TabIndex = 0;
            // 
            // sliding_timer
            // 
            this.sliding_timer.Tick += new System.EventHandler(this.sliding_timer_Tick);
            // 
            // contentPanel
            // 
            this.contentPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.contentPanel.Location = new System.Drawing.Point(250, 36);
            this.contentPanel.Name = "contentPanel";
            this.contentPanel.Size = new System.Drawing.Size(756, 540);
            this.contentPanel.TabIndex = 2;
            this.contentPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.contentPanel_Paint);
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::Library_Management_System.Properties.Resources.bg5;
            this.panel2.Controls.Add(this.abouttab);
            this.panel2.Controls.Add(this.bookstab);
            this.panel2.Controls.Add(this.borrowertab);
            this.panel2.Controls.Add(this.settingstab);
            this.panel2.Controls.Add(this.transactiontab);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 36);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(250, 540);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // abouttab
            // 
            this.abouttab.BackColor = System.Drawing.Color.Transparent;
            this.abouttab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.abouttab.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.abouttab.Image = global::Library_Management_System.Properties.Resources.information_button;
            this.abouttab.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.abouttab.Location = new System.Drawing.Point(0, 340);
            this.abouttab.Name = "abouttab";
            this.abouttab.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.abouttab.Size = new System.Drawing.Size(250, 68);
            this.abouttab.TabIndex = 7;
            this.abouttab.Text = "ABOUT";
            this.abouttab.UseVisualStyleBackColor = false;
            this.abouttab.Click += new System.EventHandler(this.abouttab_Click);
            // 
            // bookstab
            // 
            this.bookstab.BackColor = System.Drawing.Color.Transparent;
            this.bookstab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bookstab.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookstab.Image = global::Library_Management_System.Properties.Resources.open_book;
            this.bookstab.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bookstab.Location = new System.Drawing.Point(0, 68);
            this.bookstab.Name = "bookstab";
            this.bookstab.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bookstab.Size = new System.Drawing.Size(250, 68);
            this.bookstab.TabIndex = 6;
            this.bookstab.Text = "BOOKS";
            this.bookstab.UseVisualStyleBackColor = false;
            this.bookstab.Click += new System.EventHandler(this.bookstab_Click);
            // 
            // borrowertab
            // 
            this.borrowertab.BackColor = System.Drawing.Color.Transparent;
            this.borrowertab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.borrowertab.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrowertab.Image = global::Library_Management_System.Properties.Resources.borrow;
            this.borrowertab.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.borrowertab.Location = new System.Drawing.Point(0, 136);
            this.borrowertab.Name = "borrowertab";
            this.borrowertab.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.borrowertab.Size = new System.Drawing.Size(250, 68);
            this.borrowertab.TabIndex = 5;
            this.borrowertab.Text = "BORROWERS";
            this.borrowertab.UseVisualStyleBackColor = false;
            this.borrowertab.Click += new System.EventHandler(this.borrowertab_Click);
            // 
            // settingstab
            // 
            this.settingstab.BackColor = System.Drawing.Color.Transparent;
            this.settingstab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.settingstab.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.settingstab.Image = global::Library_Management_System.Properties.Resources.setting;
            this.settingstab.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.settingstab.Location = new System.Drawing.Point(0, 272);
            this.settingstab.Name = "settingstab";
            this.settingstab.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.settingstab.Size = new System.Drawing.Size(250, 68);
            this.settingstab.TabIndex = 4;
            this.settingstab.Text = "SETTINGS";
            this.settingstab.UseVisualStyleBackColor = false;
            this.settingstab.Click += new System.EventHandler(this.settingstab_Click);
            // 
            // transactiontab
            // 
            this.transactiontab.BackColor = System.Drawing.Color.Transparent;
            this.transactiontab.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.transactiontab.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transactiontab.Image = global::Library_Management_System.Properties.Resources.transaction;
            this.transactiontab.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.transactiontab.Location = new System.Drawing.Point(0, 204);
            this.transactiontab.Name = "transactiontab";
            this.transactiontab.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.transactiontab.Size = new System.Drawing.Size(250, 68);
            this.transactiontab.TabIndex = 3;
            this.transactiontab.Text = "TRANSACTIONS";
            this.transactiontab.UseVisualStyleBackColor = false;
            this.transactiontab.Click += new System.EventHandler(this.transactiontab_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Image = global::Library_Management_System.Properties.Resources.left;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(0, 0);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.button3.Size = new System.Drawing.Size(250, 68);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button2.BackgroundImage = global::Library_Management_System.Properties.Resources.close2;
            this.button2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.button2.Location = new System.Drawing.Point(969, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(28, 28);
            this.button2.TabIndex = 4;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.BackgroundImage = global::Library_Management_System.Properties.Resources.mini4;
            this.button1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.Location = new System.Drawing.Point(932, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 28);
            this.button1.TabIndex = 3;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AppBody
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1006, 576);
            this.Controls.Add(this.contentPanel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AppBody";
            this.Text = "AppBody";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Timer sliding_timer;
        private System.Windows.Forms.Button abouttab;
        private System.Windows.Forms.Button bookstab;
        private System.Windows.Forms.Button borrowertab;
        private System.Windows.Forms.Button settingstab;
        private System.Windows.Forms.Button transactiontab;
        private System.Windows.Forms.Panel contentPanel;
    }
}