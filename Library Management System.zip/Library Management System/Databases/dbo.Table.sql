﻿CREATE TABLE Transactions
(
	[Tnum] INT NOT NULL PRIMARY KEY IDENTITY, 
    [date] DATE NULL, 
    [Time] TIME NULL, 
    [br_id] INT NULL, 
    [book_num] INT NULL, 
    [Authorised_by] VARCHAR(20) NULL, 
    [return_date] DATE NULL, 
    [hasReturned] BIT NULL, 
    CONSTRAINT [FK_Transactions_ToTable] FOREIGN KEY (br_id) REFERENCES borrower(Bid), 
    CONSTRAINT [FK_Transactions_ToTable_1] FOREIGN KEY (book_num) REFERENCES books(accNo)
)
