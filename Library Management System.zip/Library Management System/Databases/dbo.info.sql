﻿CREATE TABLE [dbo].[info] (
    [Property] VARCHAR (10) NOT NULL,
    [Value]    NCHAR (10)   NULL,
    PRIMARY KEY CLUSTERED ([Property] ASC)
);

