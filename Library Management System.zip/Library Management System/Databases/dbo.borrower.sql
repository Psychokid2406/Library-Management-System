﻿CREATE TABLE [dbo].[borrower] (
    [Bid]      INT          NOT NULL,
    [Name]     VARCHAR (30) NULL,
    [Address]  VARCHAR (30) NULL,
    [Phone_No] INT          NULL,
    [Book1]    INT          NULL,
    [Book2]    INT          NULL,
    [Book3]    INT          NULL,
    PRIMARY KEY CLUSTERED ([Bid] ASC),
    CONSTRAINT [FK_borrower_ToTable] FOREIGN KEY ([Book1]) REFERENCES [dbo].[books] ([accNo]),
    CONSTRAINT [FK_borrower_ToTable_1] FOREIGN KEY ([Book2]) REFERENCES [dbo].[books] ([accNo]),
    CONSTRAINT [FK_borrower_ToTable_2] FOREIGN KEY ([Book3]) REFERENCES [dbo].[books] ([accNo])
);

