﻿CREATE TABLE [dbo].[books] (
    [accNo]     INT          NOT NULL,
    [isbn]      VARCHAR (10) NULL,
    [Name]      VARCHAR (30) NULL,
    [Author]    VARCHAR (30) NULL,
    [Publisher] VARCHAR (30) NULL,
    [did]       INT          NULL,
    [borrower]  INT          NULL,
    PRIMARY KEY CLUSTERED ([accNo] ASC),
    CONSTRAINT [FK_books_ToTable] FOREIGN KEY ([did]) REFERENCES [dbo].[department] ([dept_id]),
    CONSTRAINT [FK_books_ToTable_1] FOREIGN KEY ([borrower]) REFERENCES [dbo].[borrower] ([Bid])
);

