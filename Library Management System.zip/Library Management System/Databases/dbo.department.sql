﻿CREATE TABLE [dbo].[department] (
    [dept_id]   INT          NOT NULL,
    [dept_name] VARCHAR (20) NULL,
    [rackCode]  INT          NULL,
    PRIMARY KEY CLUSTERED ([dept_id] ASC)
);

